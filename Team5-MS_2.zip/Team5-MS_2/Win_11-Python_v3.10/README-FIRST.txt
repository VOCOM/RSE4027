# RSE4027

Dependencies:
`python3` `pip`

```
pip install pandas
pip install scikit-learn
pip install matplotlib
pip install seaborn

```

How To (Command Prompt):
For EDA:
```
python MS2EDA.py

```
For ML:
```
python MS2ML.py

```
For Visualisation:
```
python MS2VIS.py

```
